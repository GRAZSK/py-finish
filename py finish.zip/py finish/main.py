import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import json
from datetime import datetime
import os

class WeightTrackerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Трекер веса")
        self.root.geometry("600x550")
        self.root.resizable(False, False)
        

        # Данные пользователя
        self.user_data = {
            'weight': 0,
            'height': 0,
            'dream_weight': 0,
            'gender': 'female'  # по умолчанию женщина
        }
        

        # Инициализация базы данных
        self.init_database()
        
        # Создание фреймов
        self.create_frame1()
        self.create_frame2()
        
        # Показываем первый фрейм
        self.show_frame1()
        

    def init_database(self):
        """Инициализация SQLite базы данных"""
        self.conn = sqlite3.connect('weight_tracker.db')
        self.cursor = self.conn.cursor()
        
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_params (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                weight REAL,
                height REAL,
                dream_weight REAL,
                gender TEXT,
                bmi REAL,
                calories REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        self.conn.commit()
        


    def create_frame1(self):
        """Создание первой страницы (ввод данных)"""
        self.frame1 = tk.Frame(self.root, bg='#FFB6C1')
        
        # Заголовок
        title_label = tk.Label(
            self.frame1,
            text="для начала давай узнаем твои параметры",
            font=('Arial', 14, 'bold'),
            bg='#FFB6C1',
            fg='#8B008B'
        )
        title_label.pack(pady=(30, 20))
        

        # Выбор пола
        gender_frame = tk.Frame(self.frame1, bg='#FFB6C1')
        gender_frame.pack(pady=10)
        
        gender_label = tk.Label(
            gender_frame,
            text="выбери свой пол:",
            font=('Arial', 12, 'bold'),
            bg='#FFB6C1',
            fg='#4A0E4E'
        )
        gender_label.pack(pady=5)
        
        # Переменные для радиокнопок
        self.gender_var = tk.StringVar(value='female')
        
        # Фрейм для кнопок пола
        gender_buttons_frame = tk.Frame(gender_frame, bg='#FFB6C1')
        gender_buttons_frame.pack()
        
        # Кнопка "Женский"
        self.female_btn = tk.Radiobutton(
            gender_buttons_frame,
            text="♀ женский",
            variable=self.gender_var,
            value='female',
            font=('Arial', 12),
            bg='#FFB6C1',
            fg='#8B008B',
            activebackground='#FFB6C1',
            activeforeground='#FF1493',
            selectcolor='#FFB6C1',
            indicatoron=0,
            width=15,
            pady=5
        )
        self.female_btn.pack(side=tk.LEFT, padx=10)
        
        # Кнопка "Мужской"
        self.male_btn = tk.Radiobutton(
            gender_buttons_frame,
            text="♂ мужской",
            variable=self.gender_var,
            value='male',
            font=('Arial', 12),
            bg='#FFB6C1',
            fg='#8B008B',
            activebackground='#FFB6C1',
            activeforeground='#FF1493',
            selectcolor='#FFB6C1',
            indicatoron=0,
            width=15,
            pady=5
        )
        self.male_btn.pack(side=tk.LEFT, padx=10)
        
        # Фрейм для полей ввода
        input_frame = tk.Frame(self.frame1, bg='#FFB6C1')
        input_frame.pack(pady=20)
        
        # Поле "твой вес"
        weight_label = tk.Label(
            input_frame,
            text="твой вес (кг):",
            font=('Arial', 12),
            bg='#FFB6C1',
            fg='#4A0E4E'
        )
        weight_label.grid(row=0, column=0, sticky='e', padx=10, pady=10)
        
        self.weight_var = tk.StringVar()
        weight_entry = tk.Entry(
            input_frame,
            textvariable=self.weight_var,
            font=('Arial', 12),
            width=15,
            bg='white',
            relief=tk.FLAT,
            bd=2
        )
        weight_entry.grid(row=0, column=1, padx=10, pady=10)
        
        # Поле "твой рост"
        height_label = tk.Label(
            input_frame,
            text="твой рост (см):",
            font=('Arial', 12),
            bg='#FFB6C1',
            fg='#4A0E4E'
        )
        height_label.grid(row=1, column=0, sticky='e', padx=10, pady=10)
        
        self.height_var = tk.StringVar()
        height_entry = tk.Entry(
            input_frame,
            textvariable=self.height_var,
            font=('Arial', 12),
            width=15,
            bg='white',
            relief=tk.FLAT,
            bd=2
        )
        height_entry.grid(row=1, column=1, padx=10, pady=10)
        
        # Поле "твой вес мечты"
        dream_weight_label = tk.Label(
            input_frame,
            text="твой вес мечты (кг):",
            font=('Arial', 12),
            bg='#FFB6C1',
            fg='#4A0E4E'
        )
        dream_weight_label.grid(row=2, column=0, sticky='e', padx=10, pady=10)
        
        self.dream_weight_var = tk.StringVar()
        dream_weight_entry = tk.Entry(
            input_frame,
            textvariable=self.dream_weight_var,
            font=('Arial', 12),
            width=15,
            bg='white',
            relief=tk.FLAT,
            bd=2
        )
        dream_weight_entry.grid(row=2, column=1, padx=10, pady=10)
        
        # Кнопка NEXT
        next_button = tk.Button(
            self.frame1,
            text="NEXT →",
            font=('Arial', 14, 'bold'),
            bg='#FF69B4',
            fg='white',
            activebackground='#FF1493',
            activeforeground='white',
            relief=tk.FLAT,
            padx=30,
            pady=10,
            command=self.go_to_frame2
        )
        next_button.pack(pady=30)
        
    def create_frame2(self):
        """Создание второй страницы (результаты)"""
        self.frame2 = tk.Frame(self.root, bg='#FFB6C1')
        
        # Заголовок
        title_label = tk.Label(
            self.frame2,
            text="твой индекс массы тела",
            font=('Arial', 14, 'bold'),
            bg='#FFB6C1',
            fg='#8B008B'
        )
        title_label.pack(pady=(30, 10))
        
        # Поле для отображения ИМТ
        self.bmi_value = tk.StringVar()
        self.bmi_label = tk.Label(
            self.frame2,
            textvariable=self.bmi_value,
            font=('Arial', 24, 'bold'),
            bg='white',
            fg='#4A0E4E',
            width=15,
            relief=tk.FLAT,
            bd=2,
            pady=10
        )
        self.bmi_label.pack(pady=10)
        
        # Интерпретация ИМТ
        self.bmi_text = tk.StringVar()
        bmi_text_label = tk.Label(
            self.frame2,
            textvariable=self.bmi_text,
            font=('Arial', 12),
            bg='#FFB6C1',
            fg='#4A0E4E'
        )
        bmi_text_label.pack(pady=5)
        
        # Разделитель
        separator = tk.Frame(self.frame2, height=2, bg='#FF69B4', width=400)
        separator.pack(pady=20)
        
        # Заголовок калорий
        calories_title = tk.Label(
            self.frame2,
            text="сколько тебе следует есть",
            font=('Arial', 14, 'bold'),
            bg='#FFB6C1',
            fg='#8B008B'
        )
        calories_title.pack(pady=(20, 10))
        
        # Поле для отображения калорий
        self.calories_value = tk.StringVar()
        self.calories_label = tk.Label(
            self.frame2,
            textvariable=self.calories_value,
            font=('Arial', 24, 'bold'),
            bg='#4A4A4A',
            fg='white',
            width=20,
            relief=tk.FLAT,
            bd=2,
            pady=10
        )
        self.calories_label.pack(pady=10)
        
        # Дополнительная информация
        self.calories_text = tk.StringVar()
        calories_text_label = tk.Label(
            self.frame2,
            textvariable=self.calories_text,
            font=('Arial', 10),
            bg='#FFB6C1',
            fg='#4A0E4E',
            wraplength=400,
            justify='center'
        )
        calories_text_label.pack(pady=10)
        
        # Пол пользователя
        self.gender_display = tk.StringVar()
        gender_display_label = tk.Label(
            self.frame2,
            textvariable=self.gender_display,
            font=('Arial', 10, 'italic'),
            bg='#FFB6C1',
            fg='#8B008B'
        )
        gender_display_label.pack(pady=5)
        
        # Кнопка "Назад"
        back_button = tk.Button(
            self.frame2,
            text="← Назад",
            font=('Arial', 12),
            bg='#DA70D6',
            fg='white',
            activebackground='#FF1493',
            activeforeground='white',
            relief=tk.FLAT,
            padx=20,
            pady=8,
            command=self.go_to_frame1
        )
        back_button.pack(pady=20)
        

        # Кнопка "Сохранить"
        save_button = tk.Button(
            self.frame2,
            text="Сохранить данные",
            font=('Arial', 12),
            bg='#FF69B4',
            fg='white',
            activebackground='#FF1493',
            activeforeground='white',
            relief=tk.FLAT,
            padx=20,
            pady=8,
            command=self.save_results
        )
        save_button.pack(pady=10)
        

    def calculate_bmi(self, weight, height_cm):
        """Расчет индекса массы тела"""
        height_m = height_cm / 100
        bmi = weight / (height_m ** 2)
        return round(bmi, 1)
    

    def get_bmi_category(self, bmi):
        """Определение категории ИМТ"""
        if bmi < 16:
            return "выраженный дефицит массы"
        elif 16 <= bmi < 18.5:
            return "недостаточная масса тела"
        elif 18.5 <= bmi < 25:
            return "норма"
        elif 25 <= bmi < 30:
            return "избыточная масса тела"
        elif 30 <= bmi < 35:
            return "ожирение I степени"
        elif 35 <= bmi < 40:
            return "ожирение II степени"
        else:
            return "ожирение III степени"
    
    def calculate_calories(self, weight, height, gender):
        """
        Расчет калорий по формуле Миффлина-Сан Жеора
        Для веса мечты
        """
        # Базовый возраст (можно добавить поле для ввода)
        age = 25
        
        if gender == 'female':
            # Формула для женщин
            bmr = (10 * weight) + (6.25 * height) - (5 * age) - 161
        else:
            # Формула для мужчин
            bmr = (10 * weight) + (6.25 * height) - (5 * age) + 5
        
        # Коэффициент активности (средний - 1.375)
        calories = bmr * 1.375
        return round(calories)
    
    def go_to_frame2(self):
        """Переход ко второй странице с расчетами"""
        try:
            weight = float(self.weight_var.get())
            height = float(self.height_var.get())
            dream_weight = float(self.dream_weight_var.get())
            gender = self.gender_var.get()
            
            # Валидация
            if weight <= 0 or height <= 0 or dream_weight <= 0:
                messagebox.showerror("Ошибка", "Все значения должны быть положительными!")
                return
            


            if height < 50 or height > 250:
                messagebox.showerror("Ошибка", "Рост указан неверно (укажите в см)!")
                return
            
            # Сохраняем данные
            self.user_data = {
                'weight': weight,
                'height': height,
                'dream_weight': dream_weight,
                'gender': gender
            }
            


            # Расчет ИМТ для текущего веса
            bmi = self.calculate_bmi(weight, height)
            bmi_category = self.get_bmi_category(bmi)
            
            # Расчет калорий для веса мечты с учетом пола
            calories_for_dream = self.calculate_calories(dream_weight, height, gender)
            
            # Расчет разницы в весе
            weight_diff = dream_weight - weight
            
            # Определение пола для отображения
            gender_text = "женский" if gender == 'female' else "мужской"
            gender_symbol = "♀" if gender == 'female' else "♂"
            
            # Отображение результатов
            self.bmi_value.set(f"{bmi}")
            self.bmi_text.set(f"({bmi_category})")
            
            self.calories_value.set(f"{calories_for_dream} ккал/день")
            
            if weight_diff < 0:
                goal_text = f"Чтобы похудеть на {abs(weight_diff):.1f} кг\n"
            elif weight_diff > 0:
                goal_text = f"Чтобы набрать {weight_diff:.1f} кг\n"
            else:
                goal_text = "Ваш вес идеален!\n"
                
            self.calories_text.set(
                goal_text +
                f"при весе мечты {dream_weight} кг\n" +
                "(при средней активности)"
            )
            
            self.gender_display.set(f"расчет для: {gender_symbol} {gender_text} пол")
            
            # Показываем второй фрейм
            self.show_frame2()
            
        except ValueError:
            messagebox.showerror("Ошибка", "Пожалуйста, введите корректные числовые значения!")
            


    def save_results(self):
        """Сохранение результатов в базу данных"""
        try:
            bmi = float(self.bmi_value.get())
            calories_str = self.calories_value.get()
            calories = float(calories_str.replace(' ккал/день', ''))
            gender = self.user_data['gender']
            
            self.cursor.execute('''
                INSERT INTO user_params (weight, height, dream_weight, gender, bmi, calories)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (self.user_data['weight'], self.user_data['height'], 
                  self.user_data['dream_weight'], gender, bmi, calories))
            self.conn.commit()
            
            messagebox.showinfo("Успех", "Данные успешно сохранены!")
            
        except Exception as e:
            messagebox.showerror("Ошибка", f"Ошибка при сохранении: {str(e)}")
        


    def show_frame1(self):
        """Показать первый фрейм"""
        self.frame2.pack_forget()
        self.frame1.pack(fill=tk.BOTH, expand=True)
        
    def show_frame2(self):
        """Показать второй фрейм"""
        self.frame1.pack_forget()
        self.frame2.pack(fill=tk.BOTH, expand=True)
        
    def go_to_frame1(self):
        """Возврат на первую страницу"""
        self.show_frame1()
        
    def __del__(self):
        """Закрытие соединения с базой данных"""
        if hasattr(self, 'conn'):
            self.conn.close()


if __name__ == "__main__":
    root = tk.Tk()
    app = WeightTrackerApp(root)
    root.mainloop()